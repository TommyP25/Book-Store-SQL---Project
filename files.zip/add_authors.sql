INSERT INTO Owned_By (book_id, user_id) VALUES (1, 1001);
INSERT INTO Owned_By (book_id, user_id) VALUES (2, 1002);
INSERT INTO Owned_By (book_id, user_id) VALUES (99, 1003);
INSERT INTO Owned_By (book_id, user_id) VALUES (14, 1004);
INSERT INTO Owned_By (book_id, user_id) VALUES (58, 1005);